
#include <ncurses.h>
#include <unistd.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include "main_menu.hpp"

using namespace std;

#include <ncurses.h>
#include <unistd.h>
/**
 * @brief 
 * 
 * @return included files 
 */

int main()
{

	while (main_menu())
	{
	};
	return 0;
}